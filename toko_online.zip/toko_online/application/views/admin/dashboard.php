<div class="container-fluid">
<h4><div style="font-weight: bold;">Selamat Datang <?php echo $this->session->userdata('username') ?></div></h4>
                    
</div>