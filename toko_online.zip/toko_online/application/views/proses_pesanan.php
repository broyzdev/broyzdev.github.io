<div class="container-fluid">
    <div class="alert alert-success">
        <p class="text-center align-middle">Selamat, pesanan Anda Telah Berhasil Di Proses!!!</p>

    </div>
</div>